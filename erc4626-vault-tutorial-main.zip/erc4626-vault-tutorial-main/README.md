# ERC4626 Tokenized Vault tutorial

Basic vault implementation using ERC4626 standard for tokenized vaults.
